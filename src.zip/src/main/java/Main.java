// import static org.junit.jupiter.api.Assertions.assertEquals;
import java.util.Arrays;
// import org.junit.jupiter.api.Test
import java.time.LocalTime;

public class Main {
  public static void main(String[] args) {
    LocalTime time = LocalTime.now();
    Student james=new Student("James", "Bond", "007");
    Student kirk=new Student("Kirk", "Kick", "008");
    Student william=new Student("William", "Shakespeare", "009");
    Grade_Management a = new Grade_Management();
    System.out.println(james.getPeriod());
    System.out.println(kirk.getPeriod());
    System.out.println(william.getPeriod());
    System.out.println(time.getMinute());
    System.out.println((int)(Math.random()*6));
    //gonna steal some random code tomorrow morning for a name bank and what not so I dont have to program it myself/ IT'll also makei t way heasier and the nI can do the math dot random stuff and shi for the gpa and whatnot.
  }
    
  }

  // @Test
  // void addition() {
  //     assertEquals(2, 1 + 1);
  // }

